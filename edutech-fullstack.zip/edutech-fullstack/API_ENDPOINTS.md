# Edutech API endpoints

Open `/docs` for interactive Swagger documentation. All listed paths are implemented. The optional remote compiler requires configuration; otherwise it returns a documented 503 response.

For POST and DELETE, supply `X-Requested-With: Edutech`. Authentication uses the `edutech_session` HttpOnly cookie. Browser requests are restricted to the configured website origin.

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Health |
| GET | `/api/catalog` | Catalog |
| GET | `/api/courses` | Courses |
| GET | `/api/courses/{slug}` | Course |
| GET | `/api/practice` | Practice |
| GET | `/api/practice/{slug}/challenges` | Challenges |
| GET | `/api/practice/{slug}` | Practice Detail |
| GET | `/api/products` | Products |
| GET | `/api/products/{slug}` | Product |
| GET | `/api/resources` | Resources |
| GET | `/api/resources/{slug}` | Resource Detail |
| GET | `/api/community` | Community Posts |
| POST | `/api/community` | Create Post |
| DELETE | `/api/community/{post_id}` | Delete Post |
| POST | `/api/auth/signup` | Signup |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Me |
| POST | `/api/auth/logout` | Logout |
| GET | `/api/me/saved-courses` | Saved Courses |
| POST | `/api/me/saved-courses` | Save Course |
| DELETE | `/api/me/saved-courses/{slug}` | Remove Course |
| POST | `/api/enquiries` | Create Enquiry |
| GET | `/api/me/enquiries` | My Enquiries |
| POST | `/api/practice/sqlkata/run` | Run Sql |
| GET | `/api/compiler/languages` | Compiler Languages |
| POST | `/api/compiler/run` | Compile Remote |

## Authentication and response rules

- `/api/auth/me`, `/api/me/*`, creating/deleting community posts, and remote compilation require a valid session.
- Catalogs, course outlines, starter challenges, reading community posts, and read-only SQL practice are public.
- Sign-up and create operations return 201. Logout and deletes return 204 with an empty response.
- Invalid input returns 422; missing authentication returns 401; failed origin/header checks return 403; missing items return 404; duplicate email returns 409; throttling returns 429.
- POST `/api/enquiries` stores a record and returns `reference` plus `email_sent: false`. No external message is sent.
- GET `/api/compiler/languages` returns browser JavaScript without provider configuration. POST `/api/compiler/run` returns 503 when additional language execution is not configured.

## Webpage URLs

Every route below returns a webpage. Links navigate to separate URLs with the same visual theme.

| Section | Routes |
| --- | --- | --- |
| Main pages | `/`, `/courses`, `/practice`, `/resources`, `/products`, `/contact`, `/login`, `/signup`, `/dashboard` |
| Courses | `/courses/data-science`, `/courses/data-engineering`, `/courses/artificial-intelligence`, `/courses/data-science-genai`, `/courses/agentic-ai-machine-learning`, `/courses/ai-cloud-devops`, `/courses/forward-deployed-ai-engineering`, `/courses/ai-powered-automotive-design`, `/courses/ai-powered-business-analytics` |
| Practice | `/practice/codekata`, `/practice/webkata`, `/practice/sqlkata`, `/practice/fixthecode`, `/practice/ide` |
| Products | `/products/hackerkid`, `/products/corporates`, `/products/placement-preparation` |
| Resources | `/resources/free-resources`, `/resources/success-stories`, `/resources/learn-hub`, `/resources/rewards`, `/resources/leaderboard`, `/resources/referral`, `/resources/blogs`, `/resources/get-the-app`, `/resources/become-an-affiliate`, `/resources/resume-builder`, `/resources/community-hub` |
