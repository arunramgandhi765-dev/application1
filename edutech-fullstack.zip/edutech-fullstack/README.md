# Edutech website

A responsive navy-and-gold website based on the approved homepage, implemented with plain HTML/CSS/JavaScript and a same-origin FastAPI backend. Start with **START_HERE.md** for Windows/VS Code instructions.

## Architecture

The browser requests a page such as `/practice/sqlkata`. FastAPI serves the shared HTML shell. `static/app.js` renders the appropriate page and requests its data from `/api/...`. Header links have actual page URLs; direct navigation and refresh both work. Unknown API paths return JSON 404 errors; unknown page paths return a 404 page.

| Component | Implementation |
| --- | --- |
| Frontend | Plain HTML, CSS, JavaScript; no build or CDN dependency |
| Backend | FastAPI with Pydantic validation |
| Database | SQLite, created automatically on first run |
| Sessions | Random opaque cookie tokens; token hashes and expiry stored in SQLite |
| Passwords | Salted PBKDF2-HMAC-SHA256, 600,000 iterations |
| SQL practice | Fresh in-memory SQLite fixture with a read-only authorizer and execution budget |
| JavaScript practice | Opaque-origin sandboxed iframe + worker with a 2-second timeout |
| Web preview | Sandboxed iframe with external requests disabled |
| Resume | Browser-only editable preview, print/PDF and TXT export |

## Pages

- Home, Courses, Practice, Resources, Our Products, Contact, Login, Sign up, My learning.
- **9 course pages:** Data Science; Data Engineering; Artificial Intelligence; Data Science & GenAI; Next-Gen Agentic AI & Machine Learning; AI Cloud & DevOps; Forward Deployed AI Engineering; AI-Powered Automotive Design; AI-Powered Business Analytics.
- **5 practice pages:** CodeKata, WebKata, SQLKata, FixTheCode, IDE - Online Compiler.
- **11 resource pages:** Free Resources, Success Stories, Learn Hub, Rewards, Leaderboard, Referral, Blogs, Get The App, Become An Affiliate, Resume Builder, Community Hub.
- **3 product pages:** HackerKID, Edutech For Corporates, Placement Preparation.

There are no external brand assets, course prices, sale promotions or invented accreditations.

## Database tables

| Table | Purpose |
| --- | --- |
| `users` | Name, unique email, salted password hash, creation time |
| `sessions` | Hashed opaque token, user reference, expiry |
| `saved_courses` | Unique user/course pairs |
| `enquiries` | Contact name, email, topic, message, optional user reference |
| `community_posts` | Author, plain-text post, creation time |

Catalog content is in JSON rather than database tables so that a beginner can edit it easily. The SQLKata sample `employees` and `departments` tables are never part of the account database.

## Configuration

Optional: copy `.env.example` to `.env`. `app/main.py` reads this file at startup. Restart the server after changing it.

| Setting | Purpose |
| --- | --- |
| `EDUTECH_DB_PATH` | SQLite file path; relative paths resolve against the project folder |
| `EDUTECH_COOKIE_SECURE` | Set `true` for HTTPS hosting; keep `false` for local HTTP |
| `EDUTECH_PUBLIC_ORIGIN` | Exact allowed browser origin when a trusted reverse proxy changes the externally visible origin |
| `JUDGE0_URL` | Optional trusted HTTPS Judge0-compatible service base URL |
| `JUDGE0_API_KEY` | Optional provider key; kept on the server |
| `JUDGE0_RAPIDAPI_HOST` | Optional provider host header, when required by your provider |

## Optional compiler service

JavaScript runs without a remote compiler. To enable other languages, provision a Judge0-compatible service and configure its HTTPS base URL. It must support `/languages` and synchronous `/submissions?wait=true&base64_encoded=false`. The adapter sends CPU/wall-time, memory and output-file limits and disables network access in submissions. Use only a service that actually enforces execution isolation.

The language dropdown gets the provider's available languages dynamically. Remote execution requires a logged-in account. Missing configuration is reported as HTTP 503 with an explanatory message, not a fake successful compilation. A provider that does not support synchronous execution needs its own polling adapter. Provider configuration and real remote execution have not been verified in this delivered project.

## API usage

All browser requests use the same host and port as FastAPI. No wildcard CORS configuration is added.

For POST/DELETE requests, include `X-Requested-With: Edutech`. Swagger at `/docs` exposes this header with the default value. Browser-origin checks and SameSite cookies complement the custom-header requirement.

Example in PowerShell:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/courses

$headers = @{ "X-Requested-With" = "Edutech" }
$body = @{ query = "SELECT name, salary FROM employees ORDER BY salary DESC;" } | ConvertTo-Json
Invoke-RestMethod http://127.0.0.1:8000/api/practice/sqlkata/run -Method Post -Headers $headers -ContentType "application/json" -Body $body
```

## Tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The eight integration tests cover every catalog/detail URL, API errors, sign-up/login/logout, password storage, CSRF headers/origin checks, login throttling, saved-course isolation, enquiry isolation, community ownership, SQL JOINs and blocked queries, challenge data, and unconfigured compiler handling. Tests use a temporary SQLite database, not `data/edutech.db`.

## Before a public launch

The shipped app is suitable for local development and review. Add deployment-specific HTTPS, an appropriate privacy policy, email verification/password reset, administrative moderation, backups, monitored errors, and a shared rate limiter before opening it to real learners. The included rate limiter is per process and is intended for a single-process starter. Enquiry notifications, real course delivery and assessment grading require additional services/content. Never execute arbitrary submitted Python or shell code inside the web server.

A Python-capable host is needed for this project; static hosting alone cannot run its API. No hosting account, public deployment or domain is included.

## Implementation references

- FastAPI security documentation: https://fastapi.tiangolo.com/tutorial/security/oauth2-jwt/
- Python SQLite authorizer API: https://docs.python.org/3/library/sqlite3.html#sqlite3.Connection.set_authorizer

These are technical references. The project uses server-side opaque sessions rather than the JWT flow in the FastAPI example.
