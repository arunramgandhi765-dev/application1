@echo off
setlocal
cd /d "%~dp0"
echo Starting Edutech setup...
if exist ".venv\Scripts\python.exe" goto install
py -3 -m venv .venv
if errorlevel 1 python -m venv .venv
if errorlevel 1 goto failed
:install
".venv\Scripts\python.exe" -m ensurepip --upgrade
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo Open http://127.0.0.1:8000/ in your browser.
echo Keep this window open. Press Ctrl+C to stop the server.
echo.
".venv\Scripts\python.exe" -m uvicorn app.main:app --reload
pause
exit /b
:failed
echo.
echo Setup did not finish. Read the error above and START_HERE.md.
echo Make sure Python 3.11 or newer is installed and you have an internet connection.
pause
exit /b 1
