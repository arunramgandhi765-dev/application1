# Run your Edutech website

This folder contains the entire source code: the HTML/CSS/JavaScript website, the FastAPI backend, images, sample content, and tests. No Node installation or frontend build is needed.

**Windows shortcut:** after extracting the ZIP and installing Python 3.11+, double-click `RUN_WINDOWS.bat`. It creates the virtual environment, installs the requirements, and starts the website. Keep its window open, then visit `http://127.0.0.1:8000/`. Use the manual steps below if you want to run it from VS Code.

## 1. Extract and open the project

1. Right-click `edutech-fullstack.zip` and choose **Extract All**.
2. Open Visual Studio Code.
3. Choose **File → Open Folder** and select the extracted `edutech-fullstack` folder.
4. Choose **Terminal → New Terminal**. The terminal should be inside the folder containing `requirements.txt`.

You need Python **3.11 or newer** installed. In the terminal, run `py --version` to check it. If your computer uses `python` instead of `py`, replace `py` with `python` in the first command below.

## 2. Run these commands in the VS Code PowerShell terminal

Run one line at a time:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m ensurepip --upgrade
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

You do not need to activate the environment. Using its Python executable directly also avoids PowerShell execution-policy errors and the “uvicorn is not recognized” error.

On macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m uvicorn app.main:app --reload
```

## 3. Open the website

- Website: **http://127.0.0.1:8000/**
- Interactive API documentation: **http://127.0.0.1:8000/docs**
- API health check: **http://127.0.0.1:8000/api/health**

Keep the terminal running. Press **Ctrl+C** to stop the server. To start it next time, run only the last command from step 2.

**Do not open `static/index.html` by double-clicking it or use VS Code Live Server.** This website gets its content from FastAPI, so it needs the Python server.

If port 8000 is busy, add `--port 8001` to the last command and open `http://127.0.0.1:8001/` instead.

## 4. Try the main features

1. Click **Courses** to open the course page. The small chevron next to each navigation item opens its menu.
2. Click **Sign up** and create a local learner account with a password of at least 12 characters.
3. Open a course and click **Save course**. Open **My learning** to see it.
4. Open **Practice → CodeKata**. Try solving a starter exercise and click **Run checks**.
5. Open **Practice → SQLKata**, click **Load a JOIN example**, then **Run query**.
6. Open **Practice → WebKata** to edit HTML/CSS/JavaScript and update the preview.
7. Open **Resources → Resume Builder**. Fill in your details and choose **Print / Save PDF**. In the print dialog, choose **Save as PDF**.
8. Open **Resources → Community Hub** while logged in to post a question. This uses your local database; it does not send a message to an external service.

## 5. Where to edit

| File | What it changes |
| --- | --- |
| `app/catalog.json` | Course, Practice, Resource, and Product names, descriptions and outlines |
| `app/challenges.json` | Starter CodeKata and FixTheCode exercises |
| `static/styles.css` | Colours, gold borders, layout, typography and mobile styles |
| `static/app.js` | Page layouts, buttons, forms and browser practice tools |
| `static/index.html` | Shared HTML shell, page metadata and stylesheet/script links |
| `static/hero.png` | Homepage illustration |
| `app/main.py` | All backend API and webpage routes |

The home page keeps the original three course cards. The Courses page also contains the six additional topics from your screenshot. Every inner page uses the same Edutech theme. No course fees or sales offers are displayed.

## Scope you should know

This is a working website starter, not a complete commercial learning-management platform.

- Accounts, saved courses, enquiries and community posts are stored in SQLite at `data/edutech.db`. This file is created on first run.
- Enquiries are saved in the database; no email or SMS is sent. A signed-in learner can see their own enquiries in My learning. There is no admin dashboard yet.
- The IDE runs **JavaScript in the browser**. Other languages require a separate Judge0-compatible compiler service. The optional connector is included but has not been tested against a live provider. See `README.md`.
- SQL practice uses a separate in-memory sample database and permits read-only queries.
- CodeKata and FixTheCode contain five starter JavaScript exercises, not a large production question bank. Browser checks and device milestones are not verified assessment scores.
- WebKata includes a frontend editor and a live backend API example; it does not execute arbitrary Python/backend programs submitted by learners.
- Resources include real starter guides, short articles, a resume builder and community posting. Success Stories and Leaderboard have honest empty states. Rewards show local milestones. Referral copies a link; attribution and reward tracking are not implemented. Affiliate enquiries use the contact form.
- Get The App offers browser installation where supported. There is no native Android/iOS app download.
- Course outlines are editable starter content. Certification affiliations from the reference screenshots are not claimed for Edutech.
- Video lessons, payment processing, email verification, password reset, administrative moderation and production hosting are not included.

See `API_ENDPOINTS.md` for the route reference and `README.md` for architecture and tests.
