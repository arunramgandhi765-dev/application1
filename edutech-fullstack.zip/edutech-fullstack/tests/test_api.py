"""Integration tests use a temporary database; real learner data is untouched."""
import importlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

module = importlib.import_module('app.main')
HEADERS = {'X-Requested-With': 'Edutech'}


class WebsiteTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.path_patch = patch.object(module, 'DB_PATH', Path(self.directory.name) / 'test.db')
        self.path_patch.start()
        self.env_patch = patch.dict(module.os.environ, {'JUDGE0_URL': ''})
        self.env_patch.start()
        module.RATE_BUCKETS.clear()
        self.client = TestClient(module.app, headers=HEADERS)
        self.client.__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        self.path_patch.stop()
        self.env_patch.stop()
        self.directory.cleanup()

    def signup(self, email='learner@example.com', name='Test Learner'):
        response = self.client.post('/api/auth/signup', json={'name': name, 'email': email, 'password': 'A long learner passphrase'})
        self.assertEqual(response.status_code, 201, response.text)
        return response.json()

    def test_every_catalog_page_and_detail_endpoint(self):
        catalog = self.client.get('/api/catalog').json()
        count = 0
        for group, items in catalog.items():
            self.assertEqual(self.client.get('/'+group).status_code, 200)
            self.assertEqual(self.client.get('/api/'+group).status_code, 200)
            for item in items:
                route = f'/{group}/{item["slug"]}'
                self.assertEqual(self.client.get(route).status_code, 200, route)
                response = self.client.get('/api'+route)
                self.assertEqual(response.status_code, 200, route)
                self.assertEqual(response.json()['name'], item['name'])
                count += 1
        self.assertEqual(count, 28)
        for path in ['/', '/login', '/signup', '/contact', '/dashboard', '/favicon.ico', '/service-worker.js', '/static/app.js', '/static/styles.css', '/static/hero.png', '/static/runner.html', '/static/manifest.webmanifest', '/docs', '/openapi.json', '/api/health']:
            self.assertEqual(self.client.get(path).status_code, 200, path)
        self.assertEqual(self.client.get('/api/missing').status_code, 404)
        self.assertEqual(self.client.get('/missing-page').status_code, 404)
        self.assertEqual(self.client.get('/api/courses/missing').status_code, 404)

    def test_signup_login_logout_and_password_storage(self):
        self.assertEqual(self.client.get('/api/auth/me').status_code, 401)
        user = self.signup()
        self.assertEqual(self.client.get('/api/auth/me').json()['id'], user['id'])
        with module.database() as con:
            row = con.execute('SELECT password_hash FROM users').fetchone()
            self.assertNotEqual(row['password_hash'], 'A long learner passphrase')
        old_token = self.client.cookies.get(module.COOKIE)
        self.assertEqual(self.client.post('/api/auth/logout', json={}).status_code, 204)
        self.assertEqual(self.client.get('/api/auth/me').status_code, 401)
        self.assertEqual(self.client.get('/api/auth/me', headers={'Cookie': f'{module.COOKIE}={old_token}'}).status_code, 401)
        self.assertEqual(self.client.post('/api/auth/login', json={'email':user['email'],'password':'wrong'}).status_code, 401)
        login = self.client.post('/api/auth/login', json={'email':'LEARNER@example.com','password':'A long learner passphrase'})
        self.assertEqual(login.status_code, 200)
        self.assertIn('HttpOnly', login.headers['set-cookie'])
        self.assertIn('SameSite=strict', login.headers['set-cookie'])

    def test_validation_duplicates_and_csrf(self):
        bad = self.client.post('/api/auth/signup', json={'name':'Al','email':'bad','password':'short'})
        self.assertEqual(bad.status_code, 422)
        self.signup()
        duplicate = self.client.post('/api/auth/signup', json={'name':'Test','email':'learner@example.com','password':'A different long password'})
        self.assertEqual(duplicate.status_code, 409)
        self.assertEqual(self.client.post('/api/auth/logout', json={}, headers={'X-Requested-With':'wrong'}).status_code, 403)
        self.assertEqual(self.client.post('/api/auth/logout', json={}, headers={'Origin':'https://attacker.example'}).status_code, 403)

    def test_user_data_isolation_and_course_saving(self):
        self.assertEqual(self.client.get('/api/me/saved-courses').status_code, 401)
        self.signup()
        for _ in range(2):
            response=self.client.post('/api/me/saved-courses', json={'course_slug':'data-science'})
            self.assertEqual(response.status_code, 201)
        self.assertEqual(len(self.client.get('/api/me/saved-courses').json()), 1)
        self.assertEqual(self.client.post('/api/me/saved-courses', json={'course_slug':'missing'}).status_code, 404)
        enquiry=self.client.post('/api/enquiries', json={'name':'Test Learner','email':'learner@example.com','topic':'Data Science','message':'Please share the next batch information.'})
        self.assertEqual(enquiry.status_code, 201)
        self.assertFalse(enquiry.json()['email_sent'])
        self.assertEqual(len(self.client.get('/api/me/enquiries').json()), 1)
        self.client.post('/api/auth/logout', json={})
        self.signup('second@example.com')
        self.assertEqual(self.client.get('/api/me/saved-courses').json(), [])
        self.assertEqual(self.client.get('/api/me/enquiries').json(), [])
        self.client.delete('/api/me/saved-courses/data-science')
        self.client.post('/api/auth/logout', json={})
        self.client.post('/api/auth/login', json={'email':'learner@example.com','password':'A long learner passphrase'})
        self.assertEqual(len(self.client.get('/api/me/saved-courses').json()), 1)
        self.assertEqual(self.client.delete('/api/me/saved-courses/data-science').status_code, 204)
        self.assertEqual(self.client.get('/api/me/saved-courses').json(), [])

    def test_sql_joins_and_sandbox_boundaries(self):
        response=self.client.post('/api/practice/sqlkata/run', json={'query':'SELECT e.name, d.name FROM employees e JOIN departments d ON e.department_id=d.id ORDER BY e.name'})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()['rows'][0], ['Ananya','Engineering'])
        for query in ['DROP TABLE employees','SELECT * FROM users',"ATTACH DATABASE '/tmp/edutech-test.db' AS leaked",'SELECT load_extension(\'anything\')','SELECT randomblob(100000000)','SELECT * FROM sqlite_master','SELECT 1; SELECT 2;']:
            self.assertEqual(self.client.post('/api/practice/sqlkata/run', json={'query':query}).status_code, 400, query)
        self.assertEqual(self.client.post('/api/practice/sqlkata/run', json={'query':'SELECT count(*) AS total FROM employees'}).json()['rows'], [[5]])
        expensive='WITH RECURSIVE x(n) AS (SELECT 1 UNION ALL SELECT n+1 FROM x) SELECT SUM(n) FROM x;'
        self.assertEqual(self.client.post('/api/practice/sqlkata/run', json={'query':expensive}).status_code, 400)

    def test_community_ownership(self):
        self.assertEqual(self.client.post('/api/community', json={'body':'Hello learners!'}).status_code, 401)
        first=self.signup()
        post=self.client.post('/api/community', json={'body':'What should I learn after SQL?'}).json()
        self.assertEqual(post['user_id'], first['id'])
        self.assertEqual(len(self.client.get('/api/community').json()),1)
        self.client.post('/api/auth/logout',json={})
        self.signup('another@example.com')
        self.assertEqual(self.client.delete('/api/community/'+str(post['id'])).status_code,404)
        self.client.post('/api/auth/logout',json={})
        self.client.post('/api/auth/login',json={'email':first['email'],'password':'A long learner passphrase'})
        self.assertEqual(self.client.delete('/api/community/'+str(post['id'])).status_code,204)
        self.assertEqual(self.client.get('/api/community').json(),[])

    def test_compiler_configuration_and_challenge_data(self):
        languages=self.client.get('/api/compiler/languages').json()
        self.assertFalse(languages['remote_available'])
        self.assertEqual(languages['languages'][0]['id'],'javascript')
        self.assertEqual(self.client.post('/api/compiler/run',json={'language_id':71,'source_code':'print(1)'}).status_code,503)
        self.assertEqual(len(self.client.get('/api/practice/codekata/challenges').json()),3)
        self.assertEqual(len(self.client.get('/api/practice/fixthecode/challenges').json()),2)

    def test_login_rate_limit(self):
        for _ in range(10):
            self.client.post('/api/auth/login',json={'email':'unknown@example.com','password':'wrong'})
        response=self.client.post('/api/auth/login',json={'email':'unknown@example.com','password':'wrong'})
        self.assertEqual(response.status_code,429)
        self.assertIn('retry-after',response.headers)


if __name__ == '__main__':
    unittest.main()
